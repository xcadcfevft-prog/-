package com.example.fpbrowser

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import org.mozilla.geckoview.WebResponse
import java.io.File
import java.io.FileOutputStream
import java.net.URLDecoder
import kotlin.concurrent.thread

/**
 * Saves a download straight from the response Gecko already fetched. Using Android's DownloadManager instead would
 * re-request the file OUTSIDE the proxy (leaking the real IP) and without the profile's cookies.
 */
object Downloads {
    private val ui = Handler(Looper.getMainLooper())

    fun save(ctx: Context, r: WebResponse) {
        val body = r.body
        if (body == null) { toast(ctx, "下载失败：没有内容"); return }
        val name = fileName(r)
        toast(ctx, "开始下载：$name")
        thread {
            try {
                val where: String
                if (Build.VERSION.SDK_INT >= 29) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val resolver = ctx.contentResolver
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: throw java.io.IOException("insert failed")
                    resolver.openOutputStream(uri)!!.use { out -> body.use { it.copyTo(out) } }
                    cv.clear(); cv.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, cv, null, null)
                    where = "「下载」文件夹"
                } else {
                    val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir
                    dir.mkdirs()
                    FileOutputStream(File(dir, name)).use { out -> body.use { it.copyTo(out) } }
                    where = dir.absolutePath
                }
                toast(ctx, "已保存到 $where：$name")
            } catch (e: Exception) {
                toast(ctx, "下载失败：${e.message}")
            }
        }
    }

    private fun toast(ctx: Context, msg: String) { ui.post { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() } }

    private fun fileName(r: WebResponse): String {
        var name: String? = null
        val cd = r.headers.entries.firstOrNull { it.key.equals("content-disposition", true) }?.value
        if (cd != null) {
            Regex("filename\\*\\s*=\\s*[^']*'[^']*'([^;]+)", RegexOption.IGNORE_CASE).find(cd)?.let {
                name = try { URLDecoder.decode(it.groupValues[1].trim(), "UTF-8") } catch (e: Exception) { null }
            }
            if (name == null) Regex("filename\\s*=\\s*\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(cd)?.let { name = it.groupValues[1].trim() }
        }
        if (name.isNullOrBlank()) name = r.uri.substringBefore('?').substringBefore('#').substringAfterLast('/')
        val clean = (name ?: "").replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().trimStart('.')
        return if (clean.isEmpty()) "download" else clean.take(120)
    }
}
