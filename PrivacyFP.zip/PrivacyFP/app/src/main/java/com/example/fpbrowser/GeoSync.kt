package com.example.fpbrowser

import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.util.TimeZone
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * Asks a public IP-info service where the proxy's exit IP is, so the persona's timezone/language can match it.
 * The request goes THROUGH the proxy (so the service only ever sees the proxy IP) using the same tested tunnel code
 * as the relay. Plain HTTP/1.0 over a verified TLS socket: no chunked encoding to parse.
 */
object GeoSync {
    data class Geo(val ip: String?, val timezone: String, val locale: String, val country: String)

    private val endpoints = listOf("ipwho.is" to "/", "ipapi.co" to "/json/")

    fun lookup(up: ProxyRelay.Upstream): Geo? {
        for ((host, path) in endpoints) {
            try {
                val raw: Socket = up.openTunnel(host, 443, 15000)
                val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(raw, host, 443, true) as SSLSocket
                try {
                    ssl.soTimeout = 15000
                    ssl.startHandshake()
                    if (!HttpsURLConnection.getDefaultHostnameVerifier().verify(host, ssl.session)) continue
                    val req = "GET $path HTTP/1.0\r\nHost: $host\r\nUser-Agent: Mozilla/5.0\r\nAccept: application/json\r\nConnection: close\r\n\r\n"
                    ssl.outputStream.write(req.toByteArray(Charsets.US_ASCII))
                    ssl.outputStream.flush()
                    val text = ssl.inputStream.readBytes().toString(Charsets.UTF_8)
                    val body = text.substringAfter("\r\n\r\n", "")
                    val a = body.indexOf('{'); val z = body.lastIndexOf('}')
                    if (a < 0 || z <= a) continue
                    parse(JSONObject(body.substring(a, z + 1)))?.let { return it }
                } finally {
                    try { ssl.close() } catch (e: Exception) {}
                }
            } catch (e: Exception) { /* try the next endpoint */ }
        }
        return null
    }

    private fun parse(j: JSONObject): Geo? {
        val tzAny = j.opt("timezone")
        val tz = when (tzAny) {
            is String -> tzAny
            is JSONObject -> tzAny.optString("id")
            else -> ""
        }
        if (tz.isBlank() || !TimeZone.getAvailableIDs().contains(tz)) return null
        var cc = j.optString("country_code")
        if (cc.isBlank()) cc = j.optString("countryCode")
        cc = cc.uppercase()
        return Geo(j.optString("ip").ifBlank { null }, tz, localeFor(cc), cc)
    }

    private val locales = mapOf(
        "US" to "en-US", "GB" to "en-GB", "CA" to "en-CA", "AU" to "en-AU", "NZ" to "en-NZ", "IE" to "en-IE",
        "IN" to "en-IN", "SG" to "en-SG", "ZA" to "en-ZA", "DE" to "de-DE", "AT" to "de-AT", "CH" to "de-CH",
        "FR" to "fr-FR", "BE" to "nl-BE", "NL" to "nl-NL", "ES" to "es-ES", "MX" to "es-MX", "AR" to "es-AR",
        "CO" to "es-CO", "CL" to "es-CL", "IT" to "it-IT", "PT" to "pt-PT", "BR" to "pt-BR", "JP" to "ja-JP",
        "KR" to "ko-KR", "TW" to "zh-TW", "HK" to "zh-HK", "CN" to "zh-CN", "RU" to "ru-RU", "UA" to "uk-UA",
        "PL" to "pl-PL", "CZ" to "cs-CZ", "SE" to "sv-SE", "NO" to "nb-NO", "DK" to "da-DK", "FI" to "fi-FI",
        "TR" to "tr-TR", "TH" to "th-TH", "VN" to "vi-VN", "ID" to "id-ID", "MY" to "ms-MY", "PH" to "en-PH",
        "AE" to "ar-AE", "SA" to "ar-SA", "IL" to "he-IL", "GR" to "el-GR", "RO" to "ro-RO", "HU" to "hu-HU"
    )

    fun localeFor(country: String): String = locales[country] ?: "en-US"
}
