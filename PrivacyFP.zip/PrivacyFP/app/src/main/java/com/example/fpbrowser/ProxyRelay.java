package com.example.fpbrowser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/**
 * Loopback SOCKS5 relay that chains every connection to ONE authenticated upstream proxy (SOCKS5 or HTTP CONNECT).
 *
 * Why it exists: Gecko's proxy prefs cannot carry a username/password for SOCKS5. Gecko talks to this relay without
 * auth on 127.0.0.1; the relay talks to the real proxy with auth. Properties:
 *  - Domain names from Gecko are forwarded to the upstream untouched (remote DNS, no local DNS leak).
 *  - Kill switch: if the upstream fails, the connection fails. There is NO fallback to a direct connection.
 */
public final class ProxyRelay {

    /** Parsed upstream proxy description. */
    public static final class Upstream {
        public final String scheme; // "socks5" or "http"
        public final String host;
        public final int port;
        public final String user; // nullable
        public final String pass; // nullable

        public Upstream(String scheme, String host, int port, String user, String pass) {
            this.scheme = scheme; this.host = host; this.port = port; this.user = user; this.pass = pass;
        }

        /**
         * Accepted formats (scheme optional, default socks5):
         *   socks5://user:pass@host:port   http://user:pass@host:port   host:port   user:pass@host:port
         *   host:port:user:pass            (the format most proxy vendors hand out)
         */
        public static Upstream parse(String raw) {
            if (raw == null) throw new IllegalArgumentException("empty");
            String s = raw.trim();
            if (s.isEmpty()) throw new IllegalArgumentException("empty");
            String scheme = "socks5";
            int i = s.indexOf("://");
            if (i > 0) {
                String sc = s.substring(0, i).toLowerCase();
                switch (sc) {
                    case "socks5": case "socks5h": case "socks": scheme = "socks5"; break;
                    case "http": case "https": scheme = "http"; break;
                    default: throw new IllegalArgumentException("unsupported scheme: " + sc);
                }
                s = s.substring(i + 3);
            }
            String user = null, pass = null, hostPort;
            int at = s.lastIndexOf('@');
            if (at >= 0) {
                String cred = s.substring(0, at);
                hostPort = s.substring(at + 1);
                int c = cred.indexOf(':');
                if (c < 0) { user = cred; pass = ""; } else { user = cred.substring(0, c); pass = cred.substring(c + 1); }
            } else {
                String[] p = s.split(":", 4);
                if (p.length == 4) { // host:port:user:pass
                    hostPort = p[0] + ":" + p[1]; user = p[2]; pass = p[3];
                } else {
                    hostPort = s;
                }
            }
            int colon = hostPort.lastIndexOf(':');
            if (colon <= 0) throw new IllegalArgumentException("missing port");
            String host = hostPort.substring(0, colon);
            if (host.startsWith("[") && host.endsWith("]")) host = host.substring(1, host.length() - 1);
            int port;
            try { port = Integer.parseInt(hostPort.substring(colon + 1).trim()); }
            catch (NumberFormatException e) { throw new IllegalArgumentException("bad port"); }
            if (port < 1 || port > 65535 || host.isEmpty()) throw new IllegalArgumentException("bad host/port");
            if (user != null && user.isEmpty()) { user = null; pass = null; }
            return new Upstream(scheme, host, port, user, pass);
        }

        /** Short label that never contains credentials. */
        public String label() { return scheme + "://" + host + ":" + port; }

        /** Opens a tunnel to host:port through this upstream. The returned socket is positioned after the handshake. */
        public Socket openTunnel(String targetHost, int targetPort, int timeoutMs) throws IOException {
            Socket s = new Socket();
            boolean ok = false;
            try {
                s.setTcpNoDelay(true);
                s.connect(new InetSocketAddress(host, port), timeoutMs);
                s.setSoTimeout(timeoutMs);
                if (scheme.equals("http")) httpConnect(s, targetHost, targetPort);
                else socks5Connect(s, targetHost, targetPort);
                s.setSoTimeout(0);
                ok = true;
                return s;
            } finally {
                if (!ok) closeQuietly(s);
            }
        }

        private void socks5Connect(Socket s, String th, int tp) throws IOException {
            OutputStream out = s.getOutputStream();
            InputStream in = s.getInputStream();
            boolean auth = user != null;
            out.write(auth ? new byte[]{5, 2, 0, 2} : new byte[]{5, 1, 0});
            out.flush();
            byte[] r = readFully(in, 2);
            if (r[0] != 5) throw new IOException("upstream is not SOCKS5");
            if (r[1] == 2) {
                if (!auth) throw new IOException("upstream requires auth");
                byte[] u = user.getBytes(StandardCharsets.UTF_8), p = pass.getBytes(StandardCharsets.UTF_8);
                if (u.length > 255 || p.length > 255) throw new IOException("credentials too long");
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                b.write(1); b.write(u.length); b.write(u); b.write(p.length); b.write(p);
                out.write(b.toByteArray()); out.flush();
                byte[] a = readFully(in, 2);
                if (a[1] != 0) throw new IOException("upstream auth failed");
            } else if (r[1] != 0) {
                throw new IOException("upstream rejected auth methods");
            }
            ByteArrayOutputStream q = new ByteArrayOutputStream();
            q.write(5); q.write(1); q.write(0);
            if (isIPv4(th)) {
                q.write(1); q.write(InetAddress.getByName(th).getAddress());
            } else if (th.indexOf(':') >= 0) {
                q.write(4); q.write(InetAddress.getByName(th).getAddress());
            } else {
                byte[] d = th.getBytes(StandardCharsets.UTF_8);
                if (d.length > 255) throw new IOException("host too long");
                q.write(3); q.write(d.length); q.write(d);
            }
            q.write((tp >> 8) & 0xFF); q.write(tp & 0xFF);
            out.write(q.toByteArray()); out.flush();
            byte[] h = readFully(in, 4);
            if (h[0] != 5) throw new IOException("bad upstream reply");
            if (h[1] != 0) throw new IOException("upstream connect failed, code " + (h[1] & 0xFF));
            int skip;
            switch (h[3]) {
                case 1: skip = 4 + 2; break;
                case 4: skip = 16 + 2; break;
                case 3: skip = (readFully(in, 1)[0] & 0xFF) + 2; break;
                default: throw new IOException("bad upstream address type");
            }
            readFully(in, skip);
        }

        private void httpConnect(Socket s, String th, int tp) throws IOException {
            String hp = (th.indexOf(':') >= 0 ? "[" + th + "]" : th) + ":" + tp;
            StringBuilder sb = new StringBuilder();
            sb.append("CONNECT ").append(hp).append(" HTTP/1.1\r\nHost: ").append(hp).append("\r\n");
            if (user != null) {
                String cred = Base64.getEncoder().encodeToString((user + ":" + pass).getBytes(StandardCharsets.UTF_8));
                sb.append("Proxy-Authorization: Basic ").append(cred).append("\r\n");
            }
            sb.append("Proxy-Connection: Keep-Alive\r\n\r\n");
            OutputStream out = s.getOutputStream();
            out.write(sb.toString().getBytes(StandardCharsets.ISO_8859_1));
            out.flush();
            // read the response headers byte-by-byte so no tunnelled data is consumed
            InputStream in = s.getInputStream();
            ByteArrayOutputStream hdr = new ByteArrayOutputStream();
            int state = 0, b;
            while (state < 4) {
                b = in.read();
                if (b < 0) throw new IOException("upstream closed during CONNECT");
                hdr.write(b);
                if (hdr.size() > 16384) throw new IOException("upstream header too large");
                if ((b == '\r' && (state == 0 || state == 2)) || (b == '\n' && (state == 1 || state == 3))) state++;
                else state = (b == '\r') ? 1 : 0;
            }
            String first = new String(hdr.toByteArray(), StandardCharsets.ISO_8859_1);
            first = first.substring(0, Math.max(0, first.indexOf("\r\n")));
            String[] parts = first.split(" ");
            if (parts.length < 2 || !parts[1].equals("200")) throw new IOException("upstream CONNECT refused: " + first);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------

    private final Upstream upstream;
    private ServerSocket server;
    private volatile boolean running;
    private final Set<Socket> open = ConcurrentHashMap.newKeySet();
    private final ExecutorService pool = Executors.newCachedThreadPool(new ThreadFactory() {
        @Override public Thread newThread(Runnable r) { Thread t = new Thread(r, "relay"); t.setDaemon(true); return t; }
    });

    public ProxyRelay(Upstream upstream) { this.upstream = upstream; }

    /** Starts listening on 127.0.0.1 (ephemeral port) and returns the port. */
    public int start() throws IOException {
        server = new ServerSocket(0, 128, InetAddress.getByName("127.0.0.1"));
        running = true;
        pool.execute(new Runnable() {
            @Override public void run() {
                while (running) {
                    try {
                        final Socket c = server.accept();
                        open.add(c);
                        pool.execute(new Runnable() { @Override public void run() { handle(c); } });
                    } catch (IOException e) {
                        if (!running) return;
                    }
                }
            }
        });
        return server.getLocalPort();
    }

    public void stop() {
        running = false;
        closeQuietly(server);
        for (Socket s : open) closeQuietly(s);
        open.clear();
        pool.shutdownNow();
    }

    private void handle(Socket c) {
        Socket up = null;
        try {
            c.setTcpNoDelay(true);
            c.setSoTimeout(15000);
            InputStream cin = c.getInputStream();
            OutputStream cout = c.getOutputStream();
            // greeting
            byte[] g = readFully(cin, 2);
            if (g[0] != 5) return;
            byte[] methods = readFully(cin, g[1] & 0xFF);
            boolean noAuth = false;
            for (byte m : methods) if (m == 0) noAuth = true;
            if (!noAuth) { cout.write(new byte[]{5, (byte) 0xFF}); cout.flush(); return; }
            cout.write(new byte[]{5, 0}); cout.flush();
            // request
            byte[] h = readFully(cin, 4);
            if (h[0] != 5 || h[1] != 1) { reply(cout, 7); return; } // only CONNECT
            String host;
            switch (h[3]) {
                case 1: host = InetAddress.getByAddress(readFully(cin, 4)).getHostAddress(); break;
                case 4: host = InetAddress.getByAddress(readFully(cin, 16)).getHostAddress(); break;
                case 3: host = new String(readFully(cin, readFully(cin, 1)[0] & 0xFF), StandardCharsets.UTF_8); break;
                default: reply(cout, 8); return;
            }
            byte[] pb = readFully(cin, 2);
            int port = ((pb[0] & 0xFF) << 8) | (pb[1] & 0xFF);
            try {
                up = upstream.openTunnel(host, port, 15000);
            } catch (IOException e) {
                reply(cout, 4); // host unreachable — never fall back to direct
                return;
            }
            open.add(up);
            reply(cout, 0);
            c.setSoTimeout(0);
            final Socket fu = up, fc = c;
            final CountDownLatch other = new CountDownLatch(1);
            pool.execute(new Runnable() { @Override public void run() { pipe(fc, fu); other.countDown(); } });
            pipe(fu, c);
            try { other.await(); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
        } catch (IOException ignored) {
        } finally {
            open.remove(c); closeQuietly(c);
            if (up != null) { open.remove(up); closeQuietly(up); }
        }
    }

    private static void reply(OutputStream out, int code) throws IOException {
        out.write(new byte[]{5, (byte) code, 0, 1, 0, 0, 0, 0, 0, 0});
        out.flush();
    }

    /** Copies from -> to until EOF, then half-closes. */
    private static void pipe(Socket from, Socket to) {
        byte[] buf = new byte[16384];
        try {
            InputStream in = from.getInputStream();
            OutputStream out = to.getOutputStream();
            int n;
            while ((n = in.read(buf)) >= 0) { out.write(buf, 0, n); out.flush(); }
        } catch (IOException ignored) {
        } finally {
            try { to.shutdownOutput(); } catch (IOException ignored) {}
        }
    }

    static byte[] readFully(InputStream in, int n) throws IOException {
        byte[] b = new byte[n];
        int off = 0;
        while (off < n) {
            int r = in.read(b, off, n - off);
            if (r < 0) throw new IOException("eof");
            off += r;
        }
        return b;
    }

    static boolean isIPv4(String h) {
        String[] p = h.split("\\.");
        if (p.length != 4) return false;
        for (String x : p) {
            if (x.isEmpty() || x.length() > 3) return false;
            for (int i = 0; i < x.length(); i++) if (!Character.isDigit(x.charAt(i))) return false;
            if (Integer.parseInt(x) > 255) return false;
        }
        return true;
    }

    static void closeQuietly(java.io.Closeable c) { if (c != null) try { c.close(); } catch (IOException ignored) {} }
}
