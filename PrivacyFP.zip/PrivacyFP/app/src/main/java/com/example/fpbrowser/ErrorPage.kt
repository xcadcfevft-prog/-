package com.example.fpbrowser

import android.util.Base64
import org.mozilla.geckoview.WebRequestError

/** Offline error page so failed loads show a message instead of a blank view. Returned as a data: URI. */
object ErrorPage {
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    fun dataUri(uri: String?, e: WebRequestError): String {
        val what = when (e.category) {
            WebRequestError.ERROR_CATEGORY_UNKNOWN_HOST -> "找不到服务器"
            WebRequestError.ERROR_CATEGORY_SECURITY -> "安全连接失败（证书或加密问题）"
            WebRequestError.ERROR_CATEGORY_NETWORK -> "网络连接失败"
            WebRequestError.ERROR_CATEGORY_PROXY -> "代理连接失败"
            else -> "页面无法加载"
        }
        val hint = when (e.category) {
            WebRequestError.ERROR_CATEGORY_PROXY ->
                "代理不可用时本浏览器不会回落到直连（防止暴露真实 IP）。请检查「网络设置」里的代理。"
            WebRequestError.ERROR_CATEGORY_SECURITY ->
                "为保护你，已阻止不安全的连接。本浏览器仅允许 HTTPS。"
            else -> "请检查网络或网址；本浏览器仅允许 HTTPS，纯 HTTP 站点无法打开。"
        }
        val html = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font:16px/1.5 system-ui,sans-serif;margin:0;padding:28px;color:#222;background:#fff}
@media(prefers-color-scheme:dark){body{background:#16171a;color:#e6e6e6}}
h1{font-size:20px;margin:24px 0 8px}p{color:#666;margin:6px 0}code{word-break:break-all;color:#999;font-size:13px}</style></head>
<body><h1>${esc(what)}</h1><p>${esc(hint)}</p><p><code>${esc(uri ?: "")}</code></p>
<p><code>错误码 ${e.code}</code></p></body></html>"""
        return "data:text/html;charset=utf-8;base64," + Base64.encodeToString(html.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    }
}
