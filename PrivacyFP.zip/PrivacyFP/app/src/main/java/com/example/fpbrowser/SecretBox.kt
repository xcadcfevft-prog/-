package com.example.fpbrowser

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypts stored proxy credentials with a non-exportable AES key held in the Android Keystore. */
object SecretBox {
    private const val ALIAS = "privacyfp_secret_v1"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)

    fun enc(plain: String): String {
        if (plain.isEmpty()) return ""
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            "v1:" + b64(c.iv) + ":" + b64(c.doFinal(plain.toByteArray(Charsets.UTF_8)))
        } catch (e: Exception) {
            "p:" + b64(plain.toByteArray(Charsets.UTF_8))   // Keystore unavailable on this device: app-private storage only
        }
    }

    fun dec(s: String): String {
        if (s.isEmpty()) return ""
        return try {
            when {
                s.startsWith("v1:") -> {
                    val p = s.split(":")
                    val c = Cipher.getInstance("AES/GCM/NoPadding")
                    c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, unb64(p[1])))
                    String(c.doFinal(unb64(p[2])), Charsets.UTF_8)
                }
                s.startsWith("p:") -> String(unb64(s.substring(2)), Charsets.UTF_8)
                else -> ""
            }
        } catch (e: Exception) { "" }
    }
}
