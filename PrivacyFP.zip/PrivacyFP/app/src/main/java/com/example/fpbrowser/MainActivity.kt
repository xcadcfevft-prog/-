package com.example.fpbrowser

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.text.InputType
import android.text.TextUtils
import android.util.Base64
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebRequestError
import org.mozilla.geckoview.WebResponse
import java.io.File
import java.security.SecureRandom

/** One browser tab = one GeckoSession. Background tabs that were restored are only created, not loaded, until selected. */
class BrowserTab(var session: GeckoSession) {
    var url = ""
    var title = ""
    var canBack = false
    var canForward = false
    var loading = false
    var progress = 0
    var pendingUrl: String? = null
}

class MainActivity : Activity() {

    // ---- state ----
    private lateinit var profiles: Profiles
    private lateinit var profile: Profile
    private val ui = Handler(Looper.getMainLooper())
    private val tabs = mutableListOf<BrowserTab>()
    private var active: BrowserTab? = null
    private var uaOverride: String? = null
    private var engineReady = false
    private var personaReady = false
    private var personaDialogShown = false
    private var noPersist = false
    private var pendingExternalUrl: String? = null
    private var pendingFile: Pair<GeckoSession.PromptDelegate.FilePrompt, GeckoResult<GeckoSession.PromptDelegate.PromptResponse>>? = null

    // ---- views ----
    private lateinit var view: GeckoView
    private lateinit var urlBar: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var profileChip: TextView
    private lateinit var backBtn: TextView
    private lateinit var fwdBtn: TextView
    private lateinit var reloadBtn: TextView
    private lateinit var tabsCount: TextView
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var tray: LinearLayout
    private lateinit var trayList: LinearLayout
    private lateinit var trayTitle: TextView

    private val home: String by lazy {
        val html = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>PrivacyFP</title>
<style>body{margin:0;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;
font:16px system-ui,sans-serif;background:#fff;color:#222}
@media(prefers-color-scheme:dark){body{background:#16171a;color:#e6e6e6}input{background:#24262b;color:#eee;border-color:#444}}
h1{font-weight:600;font-size:26px;margin:0 0 22px}
input{width:82vw;max-width:460px;box-sizing:border-box;padding:13px 18px;font-size:16px;border:1px solid #ccc;border-radius:26px;outline:none}
p{color:#888;font-size:13px;margin-top:18px}</style></head><body>
<h1>PrivacyFP</h1>
<form action="https://duckduckgo.com/" method="get"><input name="q" type="search" placeholder="搜索或输入网址" autocomplete="off"></form>
<p>每个环境独立身份 · 仅 HTTPS</p></body></html>"""
        "data:text/html;charset=utf-8;base64," + Base64.encodeToString(html.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    }

    // =====================================================================================================
    // lifecycle
    // =====================================================================================================

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applySecureFlag()
        profiles = Profiles(this)
        profile = profiles.current
        buildUi()
        pendingExternalUrl = intent?.dataString

        // Kill switch for a broken proxy setting: never silently browse direct.
        if (profile.proxy.isNotBlank() && profile.upstream() == null) {
            AlertDialog.Builder(this).setTitle("代理地址无效")
                .setMessage("当前环境的代理格式无法识别，为避免暴露真实 IP，已阻止联网。请修正后再试。")
                .setCancelable(false)
                .setPositiveButton("去修改") { _, _ -> showNetworkSettings() }
                .show()
            return
        }
        startEngine()
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        val u = i.dataString ?: return
        if (engineReady) normalizeUrl(u)?.let { newTab(it) } else pendingExternalUrl = u
    }

    override fun onPause() {
        persistTabsNow()
        super.onPause()
    }

    @Deprecated("Activity.onBackPressed")
    override fun onBackPressed() {
        val t = active
        when {
            tray.visibility == View.VISIBLE -> hideTray()
            urlBar.hasFocus() -> { urlBar.clearFocus(); hideKeyboard() }
            fullScreenOn -> t?.session?.exitFullScreen()
            t != null && t.canBack -> t.session.goBack()
            t != null && tabs.size > 1 -> closeTab(t)
            else -> moveTaskToBack(true)
        }
    }

    // =====================================================================================================
    // engine
    // =====================================================================================================

    private fun startEngine() {
        val key = listOf(profile.id, profile.epoch, profile.proxy.hashCode(), profile.webrtc, profile.uniform,
            profile.persona.seed, profile.persona.timezone, profile.persona.locale).joinToString("|")
        if (runtime != null && runtimeKey != key) { restartApp(); return }   // engine prefs are per process

        if (runtime == null) {
            var port = 0
            val up = profile.upstream()
            if (up != null) {
                val relay = ProxyRelay(up)
                val t = Thread { try { port = relay.start() } catch (e: Exception) { port = 0 } }
                t.start(); t.join(5000)
                if (port <= 0) { toast("本地代理中继启动失败，已阻止联网"); return }
                relayRef = relay
            }
            val cfg = File(filesDir, "gecko-config.yaml")
            cfg.writeText(EngineConfig.build(profile, if (port > 0) port else null))
            val sb = GeckoRuntimeSettings.Builder()
                .configFilePath(cfg.absolutePath)
                .globalPrivacyControlEnabled(true)
                .remoteDebuggingEnabled(false)
            if (!profile.uniform) profile.persona.locale?.let { sb.locales(arrayOf(it, it.substringBefore('-'))) }
            runtime = GeckoRuntime.create(applicationContext, sb.build())
            runtimeKey = key
        }

        // Wipe queued storage (old cookie jars after "random device" / delete / clear) before any tab opens.
        for (ctx in profiles.pendingWipes()) {
            runtime!!.storageController.clearDataForSessionContext(ctx).accept({ _ -> profiles.doneWipe(ctx) }, { _ -> })
        }

        when {
            profile.uniform -> { personaReady = true; afterReady() }
            personaDone -> { uaOverride = savedUa; personaReady = true; afterReady() }   // activity recreated, process alive
            else -> installPersona()
        }
    }

    /** The persona extension asks us for the active persona over native messaging; the first page waits for "ready". */
    private fun installPersona() {
        val wec = runtime!!.webExtensionController
        wec.ensureBuiltIn("resource://android/assets/persona/", "persona@privacyfp.local").accept({ ext ->
            if (ext != null) ext.setMessageDelegate(messageDelegate, "browser")
            else personaFailed("扩展安装结果为空")
        }, { e -> personaFailed(e?.message ?: "未知错误") })
        ui.postDelayed(personaTimeout, 10000)
    }

    private val personaTimeout = Runnable { if (!personaReady) personaFailed("等待超时") }

    private val messageDelegate = object : WebExtension.MessageDelegate {
        override fun onMessage(nativeApp: String, message: Any, sender: WebExtension.MessageSender): GeckoResult<Any>? {
            val m = message as? JSONObject ?: return null
            return when (m.optString("type")) {
                "getPersona" -> {
                    uaOverride = profile.persona.applyUa(m.optString("ua"))
                    savedUa = uaOverride
                    GeckoResult.fromValue<Any>(profile.persona.forExtension())
                }
                "ready" -> {
                    onPersonaReady()
                    GeckoResult.fromValue<Any>(JSONObject().put("ok", true))
                }
                else -> null
            }
        }
    }

    private fun onPersonaReady() {
        if (personaReady) return
        personaReady = true
        personaDone = true
        ui.removeCallbacks(personaTimeout)
        afterReady()
    }

    /** Fail closed: without the persona extension pages would show the real device, so we ask before continuing. */
    private fun personaFailed(why: String) {
        if (personaReady || personaDialogShown) return
        personaDialogShown = true
        AlertDialog.Builder(this).setTitle("设备伪装未就绪")
            .setMessage("指纹扩展没有加载成功（$why）。此时打开网页会暴露真实设备特征。")
            .setCancelable(false)
            .setPositiveButton("继续等待") { _, _ -> personaDialogShown = false; ui.postDelayed(personaTimeout, 10000) }
            .setNegativeButton("仍然继续（本次不伪装）") { _, _ -> personaReady = true; afterReady() }
            .show()
    }

    private fun afterReady() {
        engineReady = true
        val saved = profiles.loadTabs(profile.id)
        val urls = saved.first
        if (urls.isEmpty()) {
            newTab(null)
        } else {
            for (u in urls) {
                val t = BrowserTab(createSession())
                t.url = u
                t.pendingUrl = if (u.isBlank()) home else u
                tabs.add(t)
            }
            selectTab(tabs[saved.second.coerceIn(0, tabs.size - 1)])
        }
        pendingExternalUrl?.let { u -> normalizeUrl(u)?.let { newTab(it) } }
        pendingExternalUrl = null
    }

    private fun createSession(): GeckoSession {
        // Same contextId for every tab of a profile = shared cookie jar inside the profile, isolated from other profiles.
        val sb = GeckoSessionSettings.Builder().contextId(profile.contextId()).usePrivateMode(false)
        uaOverride?.let { sb.userAgentOverride(it) }
        val s = GeckoSession(sb.build())
        s.progressDelegate = progressDelegate
        s.navigationDelegate = navigationDelegate
        s.contentDelegate = contentDelegate
        s.promptDelegate = promptDelegate
        // No PermissionDelegate on purpose: camera, microphone, location, notifications are never granted.
        return s
    }

    /** Process restart (prefs are fixed per process). RestartActivity lives in another process so it survives the kill. */
    private fun restartApp() {
        persistTabsNow()
        toast("正在应用新身份，约 2 秒…")
        ui.postDelayed({
            val next = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(Intent(this, RestartActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("next", next))
            Process.killProcess(Process.myPid())
        }, 350)
    }

    private fun commitAndRestart() { profiles.save(); restartApp() }

    // =====================================================================================================
    // tabs
    // =====================================================================================================

    private fun tabOf(s: GeckoSession) = tabs.firstOrNull { it.session === s }

    private fun newTab(url: String?) {
        val t = BrowserTab(createSession())
        t.pendingUrl = url ?: home
        tabs.add(t)
        selectTab(t)
    }

    private fun selectTab(t: BrowserTab) {
        val old = active
        if (old != null && old !== t) { try { old.session.setActive(false) } catch (e: Exception) { } }
        active = t
        if (!t.session.isOpen) t.session.open(runtime!!)
        view.releaseSession()
        view.setSession(t.session)
        t.session.setActive(true)
        t.pendingUrl?.let { u -> t.pendingUrl = null; t.session.loadUri(u) }
        refreshChrome()
        schedulePersist()
    }

    private fun closeTab(t: BrowserTab) {
        val i = tabs.indexOf(t)
        if (i < 0) return
        tabs.removeAt(i)
        if (active === t) {
            view.releaseSession()
            active = null
            if (tabs.isEmpty()) newTab(null) else selectTab(tabs[minOf(i, tabs.size - 1)])
        }
        try { if (t.session.isOpen) t.session.close() } catch (e: Exception) { }
        refreshTray(); refreshChrome(); schedulePersist()
    }

    /** Content process crashed / was killed by Android: swap in a fresh session and reload the page. */
    private fun recover(s: GeckoSession) {
        val t = tabOf(s) ?: return
        val u = t.url
        t.session = createSession()
        t.pendingUrl = if (u.startsWith("http")) u else home
        t.loading = false
        if (active === t) selectTab(t)
    }

    private val persistRunnable = Runnable { persistTabsNow() }
    private fun schedulePersist() { ui.removeCallbacks(persistRunnable); ui.postDelayed(persistRunnable, 800) }

    private fun persistTabsNow() {
        if (!engineReady || noPersist || tabs.isEmpty()) return
        val urls = tabs.map { t -> val u = t.pendingUrl ?: t.url; if (u.startsWith("http")) u else "" }
        profiles.saveTabs(profile.id, urls, tabs.indexOf(active).coerceAtLeast(0))
    }

    // =====================================================================================================
    // GeckoView delegates (shared by all tabs; each callback looks its tab up by session)
    // =====================================================================================================

    private val progressDelegate = object : GeckoSession.ProgressDelegate {
        override fun onPageStart(session: GeckoSession, url: String) {
            tabOf(session)?.let { it.loading = true; it.progress = 5; if (it === active) refreshChrome() }
        }
        override fun onPageStop(session: GeckoSession, success: Boolean) {
            tabOf(session)?.let { it.loading = false; it.progress = 100; if (it === active) refreshChrome() }
        }
        override fun onProgressChange(session: GeckoSession, progress: Int) {
            tabOf(session)?.let { it.progress = progress; if (it === active) refreshChrome() }
        }
    }

    private val navigationDelegate = object : GeckoSession.NavigationDelegate {
        override fun onLocationChange(
            session: GeckoSession, url: String?,
            perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>, hasUserGesture: Boolean
        ) {
            tabOf(session)?.let {
                it.url = url ?: ""
                if (it === active) refreshChrome()
                schedulePersist()
            }
        }
        override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
            tabOf(session)?.let { it.canBack = canGoBack; if (it === active) refreshChrome() }
        }
        override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
            tabOf(session)?.let { it.canForward = canGoForward; if (it === active) refreshChrome() }
        }
        /** window.open / target=_blank: a real new tab in the same profile. Gecko opens the returned session itself. */
        override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
            val t = BrowserTab(createSession())
            tabs.add(t)
            refreshChrome()
            fun waitOpen(n: Int) {
                if (!tabs.contains(t)) return
                if (t.session.isOpen) selectTab(t) else if (n < 60) ui.postDelayed({ waitOpen(n + 1) }, 30)
            }
            ui.post { waitOpen(0) }
            return GeckoResult.fromValue(t.session)
        }
        override fun onLoadError(session: GeckoSession, uri: String?, error: WebRequestError): GeckoResult<String>? {
            return GeckoResult.fromValue(ErrorPage.dataUri(uri, error))
        }
    }

    private val contentDelegate = object : GeckoSession.ContentDelegate {
        override fun onTitleChange(session: GeckoSession, title: String?) {
            tabOf(session)?.let { it.title = title ?: ""; if (tray.visibility == View.VISIBLE) refreshTray() }
        }
        override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
            Downloads.save(this@MainActivity, response)
        }
        override fun onCloseRequest(session: GeckoSession) {
            tabOf(session)?.let { closeTab(it) }
        }
        override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) { setImmersive(fullScreen) }
        override fun onCrash(session: GeckoSession) { recover(session) }
        override fun onKill(session: GeckoSession) { recover(session) }
        override fun onContextMenu(session: GeckoSession, screenX: Int, screenY: Int, element: GeckoSession.ContentDelegate.ContextElement) {
            val link = element.linkUri
            val media = element.srcUri
            val labels = ArrayList<String>(); val actions = ArrayList<() -> Unit>()
            if (link != null) {
                labels.add("在新标签页打开链接"); actions.add { normalizeUrl(link)?.let { newTab(it) } }
                labels.add("复制链接"); actions.add { copy(link) }
            }
            if (media != null) {
                labels.add("在新标签页打开图片/媒体"); actions.add { normalizeUrl(media)?.let { newTab(it) } }
                labels.add("复制图片/媒体地址"); actions.add { copy(media) }
            }
            if (labels.isEmpty()) return
            AlertDialog.Builder(this@MainActivity).setItems(labels.toTypedArray()) { _, i -> actions[i]() }.show()
        }
    }

    private val promptDelegate = object : GeckoSession.PromptDelegate {
        override fun onAlertPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.AlertPrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
            val res = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
            AlertDialog.Builder(this@MainActivity).setTitle(prompt.title).setMessage(prompt.message)
                .setPositiveButton("确定") { _, _ -> res.complete(prompt.dismiss()) }
                .setOnCancelListener { res.complete(prompt.dismiss()) }.show()
            return res
        }
        override fun onButtonPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.ButtonPrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
            val res = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
            AlertDialog.Builder(this@MainActivity).setTitle(prompt.title).setMessage(prompt.message)
                .setPositiveButton("确定") { _, _ -> res.complete(prompt.confirm(GeckoSession.PromptDelegate.ButtonPrompt.Type.POSITIVE)) }
                .setNegativeButton("取消") { _, _ -> res.complete(prompt.confirm(GeckoSession.PromptDelegate.ButtonPrompt.Type.NEGATIVE)) }
                .setOnCancelListener { res.complete(prompt.dismiss()) }.show()
            return res
        }
        override fun onTextPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.TextPrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
            val res = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
            val input = EditText(this@MainActivity).apply { setText(prompt.defaultValue ?: "") }
            AlertDialog.Builder(this@MainActivity).setTitle(prompt.title).setMessage(prompt.message).setView(input)
                .setPositiveButton("确定") { _, _ -> res.complete(prompt.confirm(input.text.toString())) }
                .setNegativeButton("取消") { _, _ -> res.complete(prompt.dismiss()) }
                .setOnCancelListener { res.complete(prompt.dismiss()) }.show()
            return res
        }
        /** <select> dropdowns and menus. */
        override fun onChoicePrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.ChoicePrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
            val res = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
            val flat = ArrayList<GeckoSession.PromptDelegate.ChoicePrompt.Choice>()
            for (c in prompt.choices) {
                val kids = c.items
                if (kids != null) { for (k in kids) flat.add(k) } else if (!c.separator) flat.add(c)
            }
            val labels = flat.map { (if (it.disabled) "（不可选）" else "") + it.label }.toTypedArray()
            val b = AlertDialog.Builder(this@MainActivity).setTitle(prompt.title ?: prompt.message)
            if (prompt.type == GeckoSession.PromptDelegate.ChoicePrompt.Type.MULTIPLE) {
                val checked = BooleanArray(flat.size) { flat[it].selected }
                b.setMultiChoiceItems(labels, checked) { _, i, on -> checked[i] = on }
                    .setPositiveButton("确定") { _, _ ->
                        val ids = flat.filterIndexed { i, c -> checked[i] && !c.disabled }.map { it.id }.toTypedArray()
                        res.complete(prompt.confirm(ids))
                    }
                    .setNegativeButton("取消") { _, _ -> res.complete(prompt.dismiss()) }
            } else {
                b.setItems(labels) { _, i -> if (flat[i].disabled) res.complete(prompt.dismiss()) else res.complete(prompt.confirm(flat[i].id)) }
            }
            b.setOnCancelListener { res.complete(prompt.dismiss()) }.show()
            return res
        }
        /** <input type=file>. */
        override fun onFilePrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.FilePrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
            val res = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
            pendingFile = Pair(prompt, res)
            val i = Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE)
            val mimes = prompt.mimeTypes
            if (mimes != null && mimes.size == 1 && mimes[0].contains("/")) {
                i.type = mimes[0]
            } else {
                i.type = "*/*"
                if (mimes != null && mimes.isNotEmpty()) {
                    val ok = mimes.filter { it.contains("/") }
                    if (ok.isNotEmpty()) i.putExtra(Intent.EXTRA_MIME_TYPES, ok.toTypedArray())
                }
            }
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, prompt.type == GeckoSession.PromptDelegate.FilePrompt.Type.MULTIPLE)
            try { startActivityForResult(i, REQ_FILE) } catch (e: Exception) { pendingFile = null; res.complete(prompt.dismiss()) }
            return res
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_FILE) return
        val pf = pendingFile ?: return
        pendingFile = null
        val uris = LinkedHashSet<Uri>()
        if (resultCode == RESULT_OK && data != null) {
            data.data?.let { uris.add(it) }
            data.clipData?.let { cd -> for (i in 0 until cd.itemCount) cd.getItemAt(i).uri?.let { uris.add(it) } }
        }
        val prompt = pf.first
        pf.second.complete(
            when (uris.size) {
                0 -> prompt.dismiss()
                1 -> prompt.confirm(this, uris.first())
                else -> prompt.confirm(this, uris.toTypedArray())
            }
        )
    }

    // =====================================================================================================
    // address bar / navigation
    // =====================================================================================================

    /** HTTPS only. Returns null for schemes we refuse to open. Anything that is not an address becomes a search. */
    private fun normalizeUrl(input: String): String? {
        val t = input.trim()
        if (t.isEmpty()) return null
        val low = t.lowercase()
        return when {
            low.startsWith("https://") -> t
            low.startsWith("http://") -> "https://" + t.substring(7)
            low.startsWith("javascript:") || low.startsWith("file:") || low.startsWith("content:") ||
                low.startsWith("data:") || low.startsWith("about:") || low.startsWith("view-source:") ||
                low.startsWith("intent:") || low.startsWith("blob:") -> null
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://duckduckgo.com/?q=" + Uri.encode(t)
        }
    }

    private fun go(input: String) {
        val u = normalizeUrl(input)
        if (u == null) { if (input.isNotBlank()) toast("不支持的地址"); return }
        val t = active ?: return
        t.session.loadUri(u)
        urlBar.clearFocus(); hideKeyboard()
    }

    private fun displayUrl(t: BrowserTab): String = if (t.url.startsWith("data:") || t.url.isBlank()) "" else t.url

    private fun refreshChrome() {
        tabsCount.text = tabs.size.toString()
        val t = active ?: return
        backBtn.alpha = if (t.canBack) 1f else 0.3f
        fwdBtn.alpha = if (t.canForward) 1f else 0.3f
        reloadBtn.text = if (t.loading) "✕" else "⟳"
        progressBar.visibility = if (t.loading && t.progress < 100) View.VISIBLE else View.GONE
        progressBar.progress = t.progress
        if (!urlBar.hasFocus()) urlBar.setText(displayUrl(t))
        profileChip.text = profile.name
    }

    // =====================================================================================================
    // tab tray
    // =====================================================================================================

    private fun showTray() { refreshTray(); tray.visibility = View.VISIBLE; hideKeyboard() }
    private fun hideTray() { tray.visibility = View.GONE }

    private fun refreshTray() {
        trayTitle.text = "标签页（${tabs.size}）· ${profile.name}"
        trayList.removeAllViews()
        for (t in tabs) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(10), dp(6), dp(10))
                background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor(if (t === active) 0xFFE3ECFF.toInt() else 0xFFF3F3F6.toInt())
                }
                setOnClickListener { hideTray(); selectTab(t) }
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val title = TextView(this).apply {
                text = t.title.ifBlank { if (displayUrl(t).isBlank()) "新标签页" else displayUrl(t) }
                textSize = 15f; setTypeface(null, Typeface.BOLD); setTextColor(0xFF1B1B1F.toInt())
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            }
            val sub = TextView(this).apply {
                text = displayUrl(t); textSize = 12f; setTextColor(0xFF777777.toInt())
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            }
            col.addView(title); col.addView(sub)
            val close = TextView(this).apply {
                text = "✕"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(0xFF555555.toInt())
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener { closeTab(t) }
            }
            card.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(close)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(12), dp(5), dp(12), dp(5))
            trayList.addView(card, lp)
        }
    }

    // =====================================================================================================
    // menus
    // =====================================================================================================

    private fun showMenu() {
        val labels = ArrayList<String>(); val actions = ArrayList<() -> Unit>()
        fun add(l: String, a: () -> Unit) { labels.add(l); actions.add(a) }
        add("＋ 新标签页") { newTab(null) }
        add("🎲 一键随机改机") { confirmNewIdentity(false) }
        add("🎲🌐 一键全新身份（改机＋换 IP）") { confirmNewIdentity(true) }
        add("🌐 仅换 IP（从代理池随机）") { rotateProxy() }
        add("⚙ 网络与隐私设置") { showNetworkSettings() }
        add("👤 环境管理（切换 / 新建 / 删除）") { showProfiles() }
        add("ℹ 当前设备与网络信息") { showInfo() }
        add("🔍 隐私自检页面") { showChecks() }
        add("🧹 清除本环境数据（Cookie/登录）") { confirmClear() }
        add(if (secureOn()) "📷 允许截屏（当前：禁止）" else "🔒 禁止截屏（当前：允许）") { toggleSecure() }
        AlertDialog.Builder(this).setItems(labels.toTypedArray()) { _, i -> actions[i]() }.show()
    }

    private fun confirmNewIdentity(withIp: Boolean) {
        val pool = profile.poolEntries()
        if (withIp && pool.isEmpty()) { toast("代理池为空：请先在「网络与隐私设置」里填入代理池"); showNetworkSettings(); return }
        AlertDialog.Builder(this).setTitle(if (withIp) "一键全新身份" else "一键随机改机")
            .setMessage(
                "将为当前环境生成一台全新的随机设备（机型、GPU、系统版本、CPU 核数、画布/音频指纹种子），" +
                "并清除该环境的全部 Cookie 与登录状态。标签页会保留，引擎需重启约 2 秒。\n\n" +
                (if (withIp) "同时会从代理池随机换一个出口 IP，并让时区/语言与之匹配。" else "出口 IP 不变；想同时换 IP 请选「一键全新身份」。")
            )
            .setPositiveButton("确定") { _, _ -> newIdentity(withIp) }
            .setNegativeButton("取消", null).show()
    }

    private fun newIdentity(withIp: Boolean) {
        val finish = {
            profiles.markWipe(profile.contextId())
            profile.epoch++
            profile.persona = Persona.random(profile.persona)    // keeps the proxy-derived timezone/locale
            commitAndRestart()
        }
        if (!withIp) { finish(); return }
        val next = pickFromPool() ?: run { toast("代理池里没有可换的代理"); return }
        applyProxy(next) { finish() }
    }

    private fun pickFromPool(): String? {
        val others = profile.poolEntries().filter { it != profile.proxy }
        if (others.isEmpty()) return null
        return others[SecureRandom().nextInt(others.size)]
    }

    private fun rotateProxy() {
        val next = pickFromPool()
        if (next == null) { toast("代理池为空或只有当前这一个代理"); showNetworkSettings(); return }
        applyProxy(next) { commitAndRestart() }
    }

    private fun confirmClear() {
        AlertDialog.Builder(this).setTitle("清除本环境数据")
            .setMessage("将删除当前环境的所有 Cookie、本地存储与缓存（等于换一个全新的空浏览器）。设备身份不变。")
            .setPositiveButton("清除") { _, _ ->
                profiles.markWipe(profile.contextId()); profile.epoch++; commitAndRestart()
            }
            .setNegativeButton("取消", null).show()
    }

    private fun showProfiles() {
        val labels = ArrayList<String>(); val actions = ArrayList<() -> Unit>()
        fun add(l: String, a: () -> Unit) { labels.add(l); actions.add(a) }
        for (p in profiles.list) {
            add((if (p.id == profile.id) "● " else "○ ") + p.name + "  ·  " + (if (p.uniform) "统一指纹" else p.persona.label())) {
                if (p.id != profile.id) { persistTabsNow(); profiles.select(p.id); restartApp() }
            }
        }
        add("＋ 新建环境（随机新设备）") { persistTabsNow(); profiles.add(); restartApp() }
        add("✎ 重命名当前环境") { renameProfile() }
        add("🗑 删除当前环境") { confirmDelete() }
        AlertDialog.Builder(this).setTitle("环境（切换会重启引擎，标签页各自保留）")
            .setItems(labels.toTypedArray()) { _, i -> actions[i]() }.show()
    }

    private fun renameProfile() {
        val input = EditText(this).apply { setText(profile.name); setSingleLine(); setSelectAllOnFocus(true) }
        AlertDialog.Builder(this).setTitle("重命名环境").setView(input)
            .setPositiveButton("确定") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) { profile.name = n.take(24); profiles.save(); refreshChrome() }
            }
            .setNegativeButton("取消", null).show()
    }

    private fun confirmDelete() {
        if (profiles.list.size <= 1) { toast("至少保留一个环境"); return }
        AlertDialog.Builder(this).setTitle("删除环境「${profile.name}」？")
            .setMessage("该环境的身份、代理设置、标签页和全部登录数据都会被永久删除。")
            .setPositiveButton("删除") { _, _ ->
                noPersist = true
                val removed = profiles.remove(profile.id)
                if (removed != null) profiles.markWipe(removed.contextId())
                restartApp()
            }
            .setNegativeButton("取消", null).show()
    }

    private fun showInfo() {
        val p = profile.persona
        val up = profile.upstream()
        val sb = StringBuilder()
        sb.append("环境：").append(profile.name).append('\n')
        if (profile.uniform) {
            sb.append("模式：统一指纹（Gecko 内置 RFP，所有用户外观一致）\n")
        } else {
            sb.append("模式：随机设备身份\n")
            sb.append("设备：").append(p.label()).append('\n')
            sb.append("GPU：").append(p.glVendor).append(" / ").append(p.glRenderer).append('\n')
            sb.append("CPU 核数：").append(p.cores).append('\n')
            sb.append("时区：").append(p.timezone ?: "跟随系统").append("　语言：").append(p.locale ?: "跟随系统").append('\n')
            sb.append("UA：").append(uaOverride ?: "引擎默认").append('\n')
        }
        sb.append("代理：").append(up?.label() ?: "无（直连，网站看到你的真实 IP）").append('\n')
        sb.append("WebRTC：").append(if (profile.webrtc) "开（不暴露本机/真实 IP）" else "关").append('\n')
        sb.append("已打开标签页：").append(tabs.size)
        AlertDialog.Builder(this).setTitle("当前设备与网络").setMessage(sb.toString()).setPositiveButton("好", null).show()
    }

    private fun showChecks() {
        val names = arrayOf("出口 IP 与 WebRTC 泄漏", "WebGL 指纹", "Canvas 指纹", "时区 / 语言", "EFF Cover Your Tracks（综合）")
        val urls = arrayOf(
            "https://browserleaks.com/ip", "https://browserleaks.com/webgl", "https://browserleaks.com/canvas",
            "https://browserleaks.com/timezone", "https://coveryourtracks.eff.org/"
        )
        AlertDialog.Builder(this).setTitle("隐私自检（在新标签页打开）")
            .setItems(names) { _, i -> newTab(urls[i]) }.show()
    }

    // =====================================================================================================
    // network settings + proxy application
    // =====================================================================================================

    private fun showNetworkSettings() {
        val pad = dp(18)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, dp(6), pad, dp(6)) }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 13f; setTextColor(0xFF555555.toInt()); setPadding(0, dp(12), 0, dp(2)) }
        val proxyIn = EditText(this).apply {
            setSingleLine(); textSize = 14f; setText(profile.proxy)
            hint = "socks5://用户:密码@主机:端口\n或 http://… 或 主机:端口:用户:密码"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val poolIn = EditText(this).apply {
            textSize = 13f; setText(profile.proxyPool); minLines = 3; gravity = Gravity.TOP or Gravity.START
            hint = "一行一个代理（格式同上）\n「换 IP」会从这里随机挑一个"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        val rtc = CheckBox(this).apply { text = "允许 WebRTC（默认关；开启也不会暴露本机/真实 IP）"; isChecked = profile.webrtc; textSize = 14f }
        val uni = CheckBox(this).apply { text = "统一指纹模式（Tor 式：所有用户一致，不做随机设备）"; isChecked = profile.uniform; textSize = 14f }
        val note = TextView(this).apply {
            text = "代理不可用时浏览器会直接断网，不会回落到直连。\n手机上没有「虚拟 IP」：出口 IP 只能来自代理/VPN/Tor（Orbot：socks5://127.0.0.1:9050）。"
            textSize = 12f; setTextColor(0xFF888888.toInt()); setPadding(0, dp(12), 0, 0)
        }
        box.addView(label("当前环境的代理（留空 = 直连）")); box.addView(proxyIn)
        box.addView(label("代理池")); box.addView(poolIn)
        box.addView(rtc); box.addView(uni); box.addView(note)
        AlertDialog.Builder(this).setTitle("网络与隐私 · ${profile.name}")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("保存并重启") { _, _ -> saveNetwork(proxyIn.text.toString().trim(), poolIn.text.toString(), rtc.isChecked, uni.isChecked) }
            .setNeutralButton("测试出口 IP") { _, _ -> testProxy(proxyIn.text.toString().trim()) }
            .setNegativeButton("取消", null).show()
    }

    private fun parseOrNull(s: String): ProxyRelay.Upstream? =
        try { ProxyRelay.Upstream.parse(s) } catch (e: Exception) { null }

    private fun saveNetwork(proxy: String, pool: String, rtc: Boolean, uni: Boolean) {
        if (proxy.isNotBlank() && parseOrNull(proxy) == null) { toast("代理格式无效"); return }
        for ((n, line) in pool.lines().withIndex()) {
            val l = line.trim()
            if (l.isNotEmpty() && !l.startsWith("#") && parseOrNull(l) == null) { toast("代理池第 ${n + 1} 行格式无效"); return }
        }
        profile.proxyPool = pool; profile.webrtc = rtc; profile.uniform = uni
        applyProxy(proxy) { commitAndRestart() }
    }

    /** Sets the profile's proxy, then (via the proxy itself) looks up where its exit IP is and aligns timezone/language. */
    private fun applyProxy(proxy: String, then: () -> Unit) {
        profile.proxy = proxy
        val up = parseOrNull(proxy)
        if (up == null) {                                   // direct: follow the real system
            profile.persona = profile.persona.withGeo(null, null)
            then(); return
        }
        val dlg = AlertDialog.Builder(this).setMessage("正在通过代理检测出口 IP 所在地…").setCancelable(false).show()
        Thread {
            val geo = GeoSync.lookup(up)
            ui.post {
                dlg.dismiss()
                if (geo != null) {
                    profile.persona = profile.persona.withGeo(geo.timezone, geo.locale)
                    toast("出口 ${geo.ip ?: ""} · ${geo.country} · ${geo.timezone}")
                } else {
                    profile.persona = profile.persona.withGeo(null, null)
                    toast("无法检测出口位置：时区/语言将跟随系统（可能与 IP 不一致）；请确认代理可用")
                }
                then()
            }
        }.start()
    }

    private fun testProxy(proxy: String) {
        val up = parseOrNull(proxy)
        if (up == null) { toast(if (proxy.isBlank()) "未设置代理" else "代理格式无效"); return }
        val dlg = AlertDialog.Builder(this).setMessage("正在通过代理检测…").setCancelable(false).show()
        Thread {
            val g = GeoSync.lookup(up)
            ui.post {
                dlg.dismiss()
                val msg = if (g == null) "检测失败：代理连不上或认证错误。\n（浏览器在这种情况下会断网，不会直连。）"
                else "出口 IP：${g.ip ?: "未知"}\n国家：${g.country}\n时区：${g.timezone}\n匹配语言：${g.locale}"
                AlertDialog.Builder(this).setTitle("代理测试").setMessage(msg).setPositiveButton("好", null).show()
            }
        }.start()
    }

    // =====================================================================================================
    // screenshots / fullscreen
    // =====================================================================================================

    private fun secureOn() = getSharedPreferences("ui", Context.MODE_PRIVATE).getBoolean("secure", true)

    private fun applySecureFlag() {
        if (secureOn()) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun toggleSecure() {
        getSharedPreferences("ui", Context.MODE_PRIVATE).edit().putBoolean("secure", !secureOn()).commit()
        applySecureFlag()
        toast(if (secureOn()) "已禁止截屏/录屏，并隐藏最近任务缩略图" else "已允许截屏")
    }

    private var fullScreenOn = false

    @Suppress("DEPRECATION")
    private fun setImmersive(on: Boolean) {
        fullScreenOn = on
        topBar.visibility = if (on) View.GONE else View.VISIBLE
        bottomBar.visibility = if (on) View.GONE else View.VISIBLE
        window.decorView.systemUiVisibility = if (on)
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        else View.SYSTEM_UI_FLAG_VISIBLE
    }

    // =====================================================================================================
    // UI construction
    // =====================================================================================================

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(m: String) { Toast.makeText(this, m, Toast.LENGTH_LONG).show() }

    private fun copy(text: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("url", text))
        toast("已复制")
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    private fun flatButton(text: String, size: Float, onClick: () -> Unit): TextView {
        val ta = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless))
        val bg = ta.getDrawable(0); ta.recycle()
        return TextView(this).apply {
            this.text = text; textSize = size; gravity = Gravity.CENTER; setTextColor(0xFF2B2B30.toInt())
            background = bg; setOnClickListener { onClick() }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; fitsSystemWindows = true; setBackgroundColor(Color.WHITE)
        }

        // top bar: profile chip + address bar
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        profileChip = TextView(this).apply {
            text = "🛡 …"; textSize = 12f; setTextColor(0xFF1D4ED8.toInt()); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            maxWidth = dp(86); setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xFFE8EEFF.toInt()) }
            setOnClickListener { showProfiles() }
        }
        urlBar = EditText(this).apply {
            hint = "搜索或输入网址"; setSingleLine(); textSize = 15f
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_TEXT_VARIATION_URI or InputType.TYPE_CLASS_TEXT
            setSelectAllOnFocus(true)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(0xFFF0F0F4.toInt()) }
            setOnEditorActionListener { _, _, _ -> go(text.toString()); true }
        }
        top.addView(profileChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val ulp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); ulp.leftMargin = dp(8)
        top.addView(urlBar, ulp)
        topBar = top

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }

        // content: GeckoView + tab tray overlay
        view = GeckoView(this)
        val content = FrameLayout(this)
        content.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        tray = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); visibility = View.GONE; isClickable = true }
        val trayHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(10), dp(8), dp(6)) }
        trayTitle = TextView(this).apply { textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(0xFF1B1B1F.toInt()); maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        val addBtn = flatButton("＋ 新标签页", 14f) { hideTray(); newTab(null) }.apply { setPadding(dp(12), dp(8), dp(12), dp(8)) }
        val doneBtn = flatButton("完成", 14f) { hideTray() }.apply { setPadding(dp(12), dp(8), dp(12), dp(8)) }
        trayHead.addView(trayTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        trayHead.addView(addBtn); trayHead.addView(doneBtn)
        trayList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(16)) }
        tray.addView(trayHead)
        tray.addView(ScrollView(this).apply { addView(trayList) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        content.addView(tray, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // bottom bar: back / forward / reload / tabs / menu
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(0xFFF7F7FA.toInt()) }
        backBtn = flatButton("◀", 20f) { active?.session?.goBack() }
        fwdBtn = flatButton("▶", 20f) { active?.session?.goForward() }
        reloadBtn = flatButton("⟳", 22f) { active?.let { if (it.loading) it.session.stop() else it.session.reload() } }
        tabsCount = TextView(this).apply {
            text = "1"; textSize = 13f; gravity = Gravity.CENTER; setTextColor(0xFF2B2B30.toInt()); setTypeface(null, Typeface.BOLD)
            background = GradientDrawable().apply { cornerRadius = dp(6).toFloat(); setStroke(dp(2), 0xFF2B2B30.toInt()); setColor(Color.TRANSPARENT) }
        }
        val tabsCell = FrameLayout(this).apply { setOnClickListener { showTray() } }
        tabsCell.addView(tabsCount, FrameLayout.LayoutParams(dp(28), dp(24), Gravity.CENTER))
        val menuBtn = flatButton("⋮", 22f) { showMenu() }
        for (v in listOf<View>(backBtn, fwdBtn, reloadBtn, tabsCell, menuBtn)) {
            bottom.addView(v, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        bottomBar = bottom

        root.addView(top)
        root.addView(progressBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(bottom)
        setContentView(root)
        profileChip.text = profile.name
    }

    companion object {
        private const val REQ_FILE = 4711
        private var runtime: GeckoRuntime? = null
        private var runtimeKey: String? = null
        private var relayRef: ProxyRelay? = null
        private var personaDone = false
        private var savedUa: String? = null
    }
}
