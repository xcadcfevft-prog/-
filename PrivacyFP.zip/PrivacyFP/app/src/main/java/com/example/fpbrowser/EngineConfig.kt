package com.example.fpbrowser

/** Builds the GeckoView config file (prefs + environment) for one profile. Applied once per process at engine start. */
object EngineConfig {

    fun build(p: Profile, relayPort: Int?): String {
        val prefs = linkedMapOf<String, Any>(
            // ---- tracking / network hygiene (all profiles) ----
            "dom.security.https_only_mode" to true,
            "dom.security.https_only_mode_ever_enabled" to true,
            "network.cookie.cookieBehavior" to 5,                 // Total Cookie Protection
            "privacy.trackingprotection.enabled" to true,
            "privacy.trackingprotection.fingerprinting.enabled" to true,
            "privacy.trackingprotection.cryptomining.enabled" to true,
            "network.http.referer.XOriginPolicy" to 2,
            "network.http.referer.XOriginTrimmingPolicy" to 2,
            "network.dns.disablePrefetch" to true,
            "network.prefetch-next" to false,
            "network.predictor.enabled" to false,
            "network.http.speculative-parallel-limit" to 0,
            "network.trr.mode" to 5,                              // DoH explicitly off: no side-channel DNS around the proxy
            "network.captive-portal-service.enabled" to false,
            "network.connectivity-service.enabled" to false,
            "browser.safebrowsing.malware.enabled" to true,
            "browser.safebrowsing.phishing.enabled" to true,
            "signon.rememberSignons" to false,
            "datareporting.healthreport.uploadEnabled" to false,
            "toolkit.telemetry.enabled" to false,
            // ---- sensors / APIs that leak hardware or location ----
            "dom.battery.enabled" to false,
            "dom.netinfo.enabled" to false,
            "dom.gamepad.enabled" to false,
            "dom.vr.enabled" to false,
            "dom.webnotifications.enabled" to false,
            "dom.push.enabled" to false,
            "media.navigator.enabled" to false,
            "geo.enabled" to false
        )

        // ---- WebRTC: either fully off, or on but unable to reveal local/real IPs ----
        if (p.webrtc) {
            prefs["media.peerconnection.enabled"] = true
            prefs["media.peerconnection.ice.default_address_only"] = true
            prefs["media.peerconnection.ice.no_host"] = true
            prefs["media.peerconnection.ice.proxy_only_if_behind_proxy"] = true   // with a proxy: WebRTC may only use it
        } else {
            prefs["media.peerconnection.enabled"] = false
        }

        // ---- identity mode ----
        if (p.uniform) {
            // Tor-style: everybody looks identical. No per-profile uniqueness on purpose.
            prefs["privacy.resistFingerprinting"] = true
            prefs["privacy.resistFingerprinting.randomDataOnCanvasExtract"] = true
            prefs["privacy.fingerprintingProtection"] = true
            prefs["privacy.spoof_english"] = 2
        } else {
            // Persona mode: a stable, per-profile identity. RFP/FPP are OFF on purpose: they force one global value
            // and add their own per-session noise, which would fight the persona and make it unstable.
            prefs["privacy.resistFingerprinting"] = false
            prefs["privacy.fingerprintingProtection"] = false
            p.persona.locale?.let { loc ->
                val lang = loc.substringBefore('-')
                val list = linkedSetOf(loc, lang, "en-US", "en")
                prefs["intl.accept_languages"] = list.joinToString(", ")
            }
        }

        // ---- proxy: Gecko only ever talks to the loopback relay; the relay holds the credentials ----
        if (relayPort != null && relayPort > 0) {
            prefs["network.proxy.type"] = 1
            prefs["network.proxy.socks"] = "127.0.0.1"
            prefs["network.proxy.socks_port"] = relayPort
            prefs["network.proxy.socks_version"] = 5
            prefs["network.proxy.socks_remote_dns"] = true        // hostnames are resolved by the proxy, never locally
            prefs["network.proxy.no_proxies_on"] = ""
            prefs["network.proxy.allow_hijacking_localhost"] = false
            prefs["network.http.http3.enable"] = false            // QUIC is UDP: it would bypass a TCP-only proxy
            if (p.webrtc) prefs["media.peerconnection.ice.proxy_only"] = true   // WebRTC may only use the proxy
        }

        val sb = StringBuilder()
        sb.append("env:")
        val tz = if (p.uniform) null else p.persona.timezone
        if (tz != null && tz.matches(Regex("[A-Za-z0-9_+\\-/]+"))) sb.append("\n  TZ: \"").append(tz).append("\"") else sb.append(" {}")
        sb.append("\nargs: []\nprefs:\n")
        for ((k, v) in prefs) {
            val value = when (v) {
                is String -> "\"" + v.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
                else -> v.toString()
            }
            sb.append("  ").append(k).append(": ").append(value).append("\n")
        }
        return sb.toString()
    }
}
