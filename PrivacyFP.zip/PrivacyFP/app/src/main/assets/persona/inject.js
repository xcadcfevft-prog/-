// PrivacyFP persona injector.
// Runs as an ISOLATED-world content script (document_start, all frames). It edits the page's real prototypes through
// wrappedJSObject + exportFunction, so no <script> tag is inserted (works under strict CSP) and the replacement
// functions report as native code. Every hook is wrapped in try/catch: a failing hook must never break a page.
// background.js swaps the persona placeholder on the line below for the active persona JSON before registering.
(function () {
  "use strict";
  const P = __PERSONA__;
  const w = window.wrappedJSObject;
  if (!w || typeof exportFunction !== "function") return;

  // ---------- deterministic noise: same seed -> same output, different seed -> different output ----------
  function hash32(str) {
    let h = 0x811c9dc5;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return h >>> 0;
  }
  const SEED = hash32(String(P.seed));
  function rnd(i, salt) {
    let h = (SEED ^ Math.imul((i | 0) + (salt | 0) * 0x632BE5AB, 0x9E3779B1)) >>> 0;
    h = Math.imul(h ^ (h >>> 16), 0x85EBCA6B) >>> 0;
    h = Math.imul(h ^ (h >>> 13), 0xC2B2AE35) >>> 0;
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }
  const unwrap = (o) => (o && o.wrappedJSObject) ? o.wrappedJSObject : o;

  // ---------- helpers ----------
  function mk(name, length, impl) {                // named function with the native arity, exported to the page
    const holder = { [name]: function () { return impl.apply(this, arguments); } };
    const fn = holder[name];
    try { Object.defineProperty(fn, "length", { value: length, configurable: true }); } catch (e) {}
    return exportFunction(fn, w);
  }
  function hook(ctorName, method, makeImpl) {
    try {
      const pageProto = w[ctorName] && w[ctorName].prototype;
      const nativeProto = window[ctorName] && window[ctorName].prototype;   // Xray view = pristine natives
      if (!pageProto || !nativeProto) return;
      const d = Object.getOwnPropertyDescriptor(pageProto, method);
      if (!d || typeof d.value !== "function") return;
      const orig = nativeProto[method];
      Object.defineProperty(pageProto, method, {
        value: mk(method, orig.length, makeImpl(orig)),
        writable: d.writable, enumerable: d.enumerable, configurable: d.configurable
      });
    } catch (e) {}
  }
  function hookGetter(ctorName, prop, value) {
    try {
      const pageProto = w[ctorName] && w[ctorName].prototype;
      const d = pageProto && Object.getOwnPropertyDescriptor(pageProto, prop);
      if (!d || !d.get) return;
      const holder = { get [prop]() { return value; } };
      const g = Object.getOwnPropertyDescriptor(holder, prop).get;
      Object.defineProperty(pageProto, prop, {
        get: exportFunction(g, w), set: d.set, enumerable: d.enumerable, configurable: d.configurable
      });
    } catch (e) {}
  }

  // ---------- CPU ----------
  if (P.cores) hookGetter("Navigator", "hardwareConcurrency", P.cores);

  // ---------- canvas ----------
  function noisePixels(d, cw, ch, salt) {          // d = RGBA bytes; flips +-1 on ~1.5% of visible pixels
    const n = d.length >> 2;
    if (n < 16) return;                            // keep tiny feature-detection canvases exact
    const s = salt ^ (cw * 31 + ch);
    for (let i = 0; i < n; i++) {
      const r = rnd(i, s);
      if (r < 0.015) {
        const o = i * 4;
        if (d[o + 3] === 0) continue;              // blank stays blank
        const c = Math.floor(r * 1e4) % 3;
        const v = d[o + c] + ((Math.floor(r * 1e6) & 1) ? 1 : -1);
        d[o + c] = v < 0 ? 1 : (v > 255 ? 254 : v);
      }
    }
  }
  if (P.canvas !== false) {
    const origGetImageData = window.CanvasRenderingContext2D && window.CanvasRenderingContext2D.prototype.getImageData;
    function noisyCopy(canvas) {                   // returns a noised temp canvas, or null to fall back to the original
      try {
        const cw = canvas.width, ch = canvas.height;
        if (!origGetImageData || !cw || !ch || cw * ch < 16 || cw * ch > 16000000) return null;
        const t = document.createElement("canvas");
        t.width = cw; t.height = ch;
        const c = t.getContext("2d");
        c.drawImage(canvas, 0, 0);
        const id = origGetImageData.call(c, 0, 0, cw, ch);
        noisePixels(id.data, cw, ch, 2);
        c.putImageData(id, 0, 0);
        return t;
      } catch (e) { return null; }
    }
    hook("CanvasRenderingContext2D", "getImageData", (orig) => function (sx, sy, sw, sh) {
      const img = orig.apply(this, arguments);
      try { noisePixels(unwrap(img).data, img.width, img.height, 1); } catch (e) {}
      return img;
    });
    hook("HTMLCanvasElement", "toDataURL", (orig) => function (type, quality) {
      const t = noisyCopy(this);
      return orig.apply(t || this, arguments);
    });
    hook("HTMLCanvasElement", "toBlob", (orig) => function (callback, type, quality) {
      const t = noisyCopy(this);
      return orig.apply(t || this, arguments);
    });
  }

  // ---------- WebGL ----------
  if (P.webgl !== false) {
    for (const ctor of ["WebGLRenderingContext", "WebGL2RenderingContext"]) {
      hook(ctor, "getParameter", (orig) => function (pname) {
        if (pname === 37445 && P.glVendor) return P.glVendor;      // UNMASKED_VENDOR_WEBGL
        if (pname === 37446 && P.glRenderer) return P.glRenderer;  // UNMASKED_RENDERER_WEBGL
        return orig.apply(this, arguments);
      });
      hook(ctor, "readPixels", (orig) => function (x, y, width, height, format, type, pixels) {
        const r = orig.apply(this, arguments);
        try {
          const a = unwrap(pixels);
          if (a && a.length && format === 6408 && type === 5121) noisePixels(a, width, height, 4);  // RGBA / UNSIGNED_BYTE
        } catch (e) {}
        return r;
      });
    }
  }

  // ---------- audio ----------
  if (P.audio !== false) {
    const seen = new WeakSet();
    hook("AudioBuffer", "getChannelData", (orig) => function (channel) {
      const arr = orig.apply(this, arguments);
      try {
        const a = unwrap(arr);
        if (a && !seen.has(a)) {
          seen.add(a);
          for (let i = 0; i < a.length; i += 97) a[i] += (rnd(i, 3) - 0.5) * 2e-7;
        }
      } catch (e) {}
      return arr;
    });
    hook("AnalyserNode", "getFloatFrequencyData", (orig) => function (array) {
      const r = orig.apply(this, arguments);
      try { const a = unwrap(array); for (let i = 0; i < a.length; i++) a[i] += (rnd(i, 5) - 0.5) * 1e-3; } catch (e) {}
      return r;
    });
  }
})();
