"use strict";
// Asks the app (native messaging, app name "browser") for the active persona, then registers the injector
// as a content script for every page. The app holds back the first page load until we report "ready".
const NATIVE = "browser";

async function boot() {
  const src = await (await fetch(browser.runtime.getURL("inject.js"))).text();
  for (let i = 0; i < 200; i++) {                 // the app attaches its delegate a moment after startup
    try {
      const persona = await browser.runtime.sendNativeMessage(NATIVE, { type: "getPersona", ua: navigator.userAgent });
      if (persona && persona.seed) {
        const marker = "const P = __PERSONA__;";
        if (!src.includes(marker)) throw new Error("inject.js marker missing");
        const code = src.replace(marker, () => "const P = " + JSON.stringify(persona) + ";");
        await browser.contentScripts.register({
          matches: ["<all_urls>"],
          js: [{ code }],
          runAt: "document_start",
          allFrames: true,
          matchAboutBlank: true
        });
        await browser.runtime.sendNativeMessage(NATIVE, { type: "ready" });
        return;
      }
    } catch (e) { /* delegate not attached yet, retry */ }
    await new Promise(r => setTimeout(r, 150));
  }
}
boot();
