# PrivacyFP 3.0 – 手机指纹浏览器（Android / GeckoView）

引擎：Mozilla GeckoView（真 Firefox 内核）。**每个「环境」= 一台独立的虚拟设备 + 独立的 Cookie 罐 + 独立的网络出口。**

## 日常使用
- 底部栏：后退 / 前进 / 刷新(停止) / 标签页 / 菜单；顶部：环境名 + 地址栏。
- 多标签：点标签数字进入标签页管理；长按链接可「在新标签页打开」；网页 `window.open`/`target=_blank` 自动开新标签。
- 重启 App 后标签页自动恢复（只加载当前标签，其余懒加载，省内存更流畅；URL 加密存储）。
- 支持：下拉选择框、文件上传、alert/confirm/prompt、下载（走 Gecko 自己的连接，不会绕过代理）、视频全屏、从其他 App 打开链接（默认升级 HTTPS）。

## 隐私功能
| 功能 | 做法 |
|---|---|
| **一键随机改机** | 重新抽一台真实机型（Pixel/Galaxy/小米/一加…，GPU、Android 版本、核数同源抽取，互不矛盾）+ 新的画布/音频噪声种子 + 新 Cookie 罐，旧数据排队清除 |
| **一键全新身份** | 改机 + 从代理池随机换出口 IP，并按出口所在地自动匹配时区/语言 |
| **换 IP** | 本地回环 SOCKS5 中继 → 你的上游代理（SOCKS5 或 HTTP CONNECT，支持用户名密码）。域名由代理解析（无本地 DNS 泄漏）。**代理失效 = 直接断网，绝不回落直连** |
| 环境隔离 | 每个环境独立 `contextId`；随机改机/清除会换新 contextId |
| WebRTC | 默认关闭；开启时也禁用 host 候选，有代理时仅走代理 |
| 其它 | 仅 HTTPS、Total Cookie Protection、跟踪/指纹脚本拦截、DoH 关闭、HTTP/3 在代理下关闭、不授予摄像头/麦克风/定位、GPC、FLAG_SECURE(可在菜单关)、代理凭据用 Android Keystore 加密 |
| 统一指纹模式 | 可选：改用 Gecko 内置 RFP（Tor 式「所有人一致」）。**这是对抗指纹追踪最稳的方式**，但没有「每机不同」 |

## 随机设备身份 = 怎么实现的
`assets/persona/` 是一个内置 WebExtension。App 通过 native messaging 把当前环境的 persona 交给它，它在每个页面 `document_start` 注册内容脚本：
- 用 `exportFunction` + `wrappedJSObject` 改页面原型，**不插入 `<script>`**（严格 CSP 站点也生效），替换函数 `toString()` 仍是 native 外观；
- 画布 / WebGL readPixels 噪声由 seed 确定性生成：**同环境永远一致，不同环境互不相同**；
- WebGL `UNMASKED_VENDOR/RENDERER`、`hardwareConcurrency`、音频缓冲噪声同理；
- UA 取引擎真实 UA，仅替换 Android 版本，Gecko 版本永远与真实引擎一致。
- **改了 `inject.js` / `background.js` 后必须把 `manifest.json` 里的 `version` 加一**，否则 `ensureBuiltIn` 认为已安装不会更新。

## 构建
推到 GitHub → Actions →「Build APK」→ 下载 `PrivacyFP-debug-apk`。
默认 `geckoVersion=+`（最新版）。若 GeckoView 改了 API 导致编译失败，或想可复现构建，请在 workflow 里加 `-PgeckoVersion=<精确版本>`。

## 已知限制（请务必读）
1. **指纹不是 C++ 级别伪造**。GeckoView 是官方预编译库，改不了引擎。分辨率、字体列表、WebGL 的 MAX_* 参数/扩展列表/着色器精度、TLS 指纹仍是真机的 —— 强追踪方理论上能把你的多个环境关联起来。想要 Camoufox 那种 C++ 级伪造，只能自己编译 Gecko（工程量巨大）。
2. **WebGL 厂商/渲染器是字符串伪装**：与真实 GPU 能力参数不一致，高级检测可能识别出矛盾。
3. **时区通过 `TZ` 环境变量**设置，我没能在真机验证 Gecko-Android 是否采用 → 请用菜单「隐私自检 → 时区」确认；不生效就告诉我，改为 JS 层方案。
4. **切换环境 / 改机会重启引擎**（Gecko prefs 按进程固定），约 2 秒，标签页保留。
5. 无「虚拟 IP」：手机上出口 IP 只能来自代理 / VPN / Tor（Orbot：`socks5://127.0.0.1:9050`）。
6. 未实现：密码管理、书签/历史（隐私浏览器刻意不留）、HTTP 认证弹窗、拦截广告。
